import Foundation

public class SDK_IDnV {
    
    var config: [String: String]?
    
    public init(config: [String: String]) {
        self.config = config
    }
    
    public func livenessOnIDnV() {
        print("This func is only on IDnV with config: \n\(config!)")
    }
    
    public func runBiometric() {
        print("Run biometric")
    }
}
