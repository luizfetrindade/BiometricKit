import Foundation

public class SDK_Unico {
    
    public init() {}
    
    public func livenessOnUnico() {
        print("This func is only on Unico")
    }
}
