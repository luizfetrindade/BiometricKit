import Foundation

public class SDK_IDWall {
    
    public init() {}
    
    public func livenessOnIDWall() {
        print("This func is only on IDWall")
    }
}
