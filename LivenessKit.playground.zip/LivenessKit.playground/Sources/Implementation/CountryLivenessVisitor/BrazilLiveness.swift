import Foundation

public final class BrazilLiveness: LivinessProtocol {
    
    public var sdk: SDKProtocol
    
    public init(sdk: SDKProtocol) {
        self.sdk = sdk
    }
    
    public func startLivenessProof() {
        sdk.startLiveness()
    }
}
