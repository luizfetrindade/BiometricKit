import Foundation

public protocol ArgentineLivenessProtocol: LivinessProtocol {
    
    func startBiometricProof()
}

public final class ArgentineLiveness: ArgentineLivenessProtocol {
    
    public var sdk: SDKProtocol
    
    public init(sdk: SDKProtocol) {
        self.sdk = sdk
    }
    
    public func startLivenessProof() {
        sdk.startLiveness()
    }
    
    public func startBiometricProof() {
//        sdk.startBiometric()
    }
}


