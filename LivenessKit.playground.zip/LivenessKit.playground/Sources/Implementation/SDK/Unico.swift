import Foundation

public final class Unico: SDKProtocol {
    
    let sdk: SDK_Unico
    
    public init() {
        sdk = SDK_Unico()
    }
    
    public func startLiveness() {
        sdk.livenessOnUnico()
    }
}
