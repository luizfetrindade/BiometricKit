import Foundation
//import IDWall

public final class IDwall: SDKProtocol {
    
   private var sdk: SDK_IDWall
    
    public init() {
        sdk = SDK_IDWall()
    }
    
    public func startLiveness() {
        sdk.livenessOnIDWall()
    }
}
