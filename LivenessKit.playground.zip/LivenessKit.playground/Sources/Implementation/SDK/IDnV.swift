import Foundation

public protocol IDnVProtocol: SDKProtocol {
    var config: [String: String] {get}
    func startBiometric()
}


public final class IDnV: IDnVProtocol {
    
    private var sdk: SDK_IDnV
    public var config: [String : String]
    
    public init(config: [String: String]) {
        self.config = config
        sdk = SDK_IDnV(config: config)
    }
    
    public func startLiveness() {
        sdk.livenessOnIDnV()
    }
    
    public func startBiometric() {
        sdk.runBiometric()
    }
}

