import Foundation

public protocol SDKProtocol {
    
    func startLiveness()
}
