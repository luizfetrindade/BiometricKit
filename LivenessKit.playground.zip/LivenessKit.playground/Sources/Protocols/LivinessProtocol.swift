public protocol LivinessProtocol {
    
    var sdk: SDKProtocol {get}
    
    func startLivenessProof()
}
