import UIKit

enum CountryCode {
    case ar, br, brl
}

func getServiceForCountry(_ countryCode: CountryCode) -> LivinessProtocol {
    switch countryCode {
    case .ar:
        return ArgentineLiveness(sdk: IDnV(config: ["Liveness": "YES"]))
    case .br:
        return BrazilLiveness(sdk: Unico())
    case .brl:
        return BrazilLegacyLiveness(sdk: IDwall())
    }
}

//MARK: - CÓDIGO LEGADO A PARTIR DAQUI
//import BiometricKit
let service = getServiceForCountry(.ar)
service.startLivenessProof()
service.startBiometric()
